import SwiftUI

struct ContentView: View {
    @State private var count = 0
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Binary Counter")
                .font(.largeTitle)
            Text("\(count)")
                .font(.system(size: 60))
            Text(String(count, radix: 2).padding(toLength: 4, withPad: "0", startingAt: 0))
                .font(.title)
            Button("Increment") {
                count = count == 15 ? 0 : count + 1
            }
        }
    }
}

