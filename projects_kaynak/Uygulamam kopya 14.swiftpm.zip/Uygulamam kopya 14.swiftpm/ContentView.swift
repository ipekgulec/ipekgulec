import SwiftUI

// Bu, külah şeklidir (değiştirme!)
struct Triangle: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.midX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.closeSubpath()
        return path
    }
}

struct ContentView: View {
    // Dondurma toplarının renkleri (başlangıçta boş)
    @State private var scoop1: Color? = nil
    @State private var scoop2: Color? = nil
    @State private var scoop3: Color? = nil
    @State private var scoop4: Color? = nil
    @State private var scoop5: Color? = nil
    
    var body: some View {
        VStack(spacing: 30) {
            Text("🍦 Ice Cream Cone")
                .font(.title)
            
            ZStack(alignment: .bottom) {
                // Külah
                Triangle()
                    .fill(.brown)
                    .frame(width: 100, height: 120)
                
                // Dondurma toplarını sırayla göster
                VStack(spacing: -10) {
                    if let color5 = scoop5 {
                        scoopCircle(color: color5, number: 5)
                    }
                    if let color4 = scoop4 {
                        scoopCircle(color: color4, number: 4)
                    }
                    if let color3 = scoop3 {
                        scoopCircle(color: color3, number: 3)
                    }
                    if let color2 = scoop2 {
                        scoopCircle(color: color2, number: 2)
                    }
                    if let color1 = scoop1 {
                        scoopCircle(color: color1, number: 1)
                    }
                }
            }
            
            HStack(spacing: 20) {
                Button("Add Scoop") {
                    addScoop()
                }
                
                Button("Reset") {
                    resetScoops()
                }
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
    
    // Renkli ve numaralı topu oluşturan fonksiyon
    func scoopCircle(color: Color, number: Int) -> some View {
        Text("\(number)")
            .frame(width: 80, height: 80)
            .background(color)
            .clipShape(Circle())
            .overlay(Circle().stroke(Color.white, lineWidth: 2))
            .foregroundColor(.white)
            .font(.title2)
    }
    
    // Top ekleme fonksiyonu
    func addScoop() {
        if scoop1 == nil {
            scoop1 = .pink
        } else if scoop2 == nil {
            scoop2 = .mint
        } else if scoop3 == nil {
            scoop3 = .yellow
        } else if scoop4 == nil {
            scoop4 = .purple
        } else if scoop5 == nil {
            scoop5 = .orange
        } else {
            // 5'ten fazla → overflow → resetle
            resetScoops()
        }
    }
    
    // Reset fonksiyonu
    func resetScoops() {
        scoop1 = nil
        scoop2 = nil
        scoop3 = nil
        scoop4 = nil
        scoop5 = nil
    }
}

#Preview {
    ContentView()
}
       
